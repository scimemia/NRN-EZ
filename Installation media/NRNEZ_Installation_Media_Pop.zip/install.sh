#!/bin/bash
in_dir="/usr/local/nrnez"
zipfile="./NRNEZ_*_Pop.zip"
mediafile="./NRNEZ_*_Pop"
icon="$HOME/Desktop/NRNEZ.desktop"
aliasfile="$HOME/.bash_aliases"

set -e
### check if NRNEZ is already installed ###
if [ -d $in_dir ]; then
    read -p "NRNEZ is already installed on this computer.
To install NRNEZ, the previous version will be removed.
Would you like to continue? [y/n]: " yn

    case $yn in
	[Yy] ) sudo rm -rf ${in_dir}
	       sudo rm -f ${icon} ;;
	[Nn] ) exit 0;;
	* ) echo "Invalid Input, exiting"
	    exit 0 ;;
    esac
else
    :
fi

### directory doesn't already exist or we deleted it, so create it ###    
sudo mkdir ${in_dir}

### unzip media ###
sudo unzip -u -q ${zipfile}

### copy media to install directory ###
sudo cp -R ${mediafile}/* ${in_dir}

### create desktop icon ###
echo "[Desktop Entry]" | sudo tee ${icon}
echo "Version=1.0" | sudo tee -a ${icon}
echo "Name=Neuron EZ" | sudo tee -a ${icon}
echo "Comment=Neuron EZ" | sudo tee -a ${icon}
echo "Exec=/usr/local/nrnez/NRN-EZ" | sudo tee -a ${icon}
echo "Icon=/usr/local/nrnez/incl/nrnez.png" | sudo tee -a ${icon}
echo "Terminal=false" | sudo tee -a ${icon}
echo "Type=Application" | sudo tee -a ${icon}
echo "Categories=Application" | sudo tee -a ${icon}

### permissions for the desktop icon ###
sudo chown $USER ${icon}
sudo chgrp $USER ${icon}
sudo chmod +x ${icon}

## permissions for install dir
sudo chown -R $USER ${in_dir}
sudo chgrp -R $USER ${in_dir}
sudo chmod -R +x ${in_dir}

##cleanup unzipped file

sudo rm -r -f ${mediafile}/

### add nrnez command to shell ###
echo "alias nrnez='/usr/local/nrnez/NRN-EZ/NRN-EZ'" | sudo tee -a ${aliasfile}

echo ""
echo "Neuron EZ installed sucessfully!"
