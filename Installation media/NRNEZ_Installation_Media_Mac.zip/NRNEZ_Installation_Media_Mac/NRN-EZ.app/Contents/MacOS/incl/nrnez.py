### version 1.1.6 ###
import os
os.system('nrnivmodl')
from neuron import h, gui
h.load_file("nrnez.hoc")
